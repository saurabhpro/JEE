mvn compile exec:java -Dexec.mainClass=course.BlogController

